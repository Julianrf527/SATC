#!/bin/sh
# ====================================
# SATC - Setup Cron para Backups Automáticos
# ====================================
# Este script configura cron para ejecutar backups cada 30 minutos
# ====================================

set -e

echo "========================================="
echo "SATC - Configurando Backups Automáticos"
echo "Frecuencia: Cada 30 minutos"
echo "========================================="

# Crear directorios de backup si no existen
mkdir -p /backups/postgres-users
mkdir -p /backups/postgres-sanctioning
mkdir -p /backups/postgres-docs
mkdir -p /backups/minio

# Hacer ejecutable el script de backup
chmod +x /backup-all.sh

# Configurar cron job (cada 30 minutos)
echo "*/30 * * * * /backup-all.sh >> /var/log/backup-cron.log 2>&1" > /etc/crontabs/root

# Agregar logging inicial
echo "# Cron job configurado: $(date)" >> /var/log/backup-cron.log
echo "# Backups automáticos cada 30 minutos" >> /var/log/backup-cron.log
echo "=========================================" >> /var/log/backup-cron.log

echo ""
echo "✓ Cron job configurado: */30 * * * * (cada 30 minutos)"
echo "✓ Log file: /var/log/backup-cron.log"
echo ""

# Ejecutar un backup inicial inmediatamente
echo "Ejecutando backup inicial..."
/backup-all.sh

echo ""
echo "✓ Backup inicial completado"
echo "✓ Iniciando crond en foreground..."
echo ""

# Iniciar crond en foreground para mantener el contenedor activo
exec crond -f -l 2
